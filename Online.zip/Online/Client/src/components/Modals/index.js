import ModalThemBaiViet from '../Modals/ModalThemBaiViet';
import ModalChiTietBaiViet from '../Modals/ModalChiTietBaiViet';
import ModalThemCategory from '../Modals/ModalThemCategory';
import ModalChiTietCategory from '../Modals/ModalChiTietCategory';
import ModalThemBrand from '../Modals/ModalThemBrand';
import ModalChiTietBrand from '../Modals/ModalChiTietBrand';
import ModalChiTietProduct_Admin from '../Modals/ModalChiTietProduct_Admin';
import ModalChiTietProduct_ChuShop from '../Modals/ModalChiTietProduct_ChuShop';
import ModalChiTietDonHang_ChuShop from '../Modals/ModalChiTietDonHang_ChuShop';
import ModalChiTietCauHoi from '../Modals/ModalChiTietCauHoi';
import ModalChiTietNhanXet from '../Modals/ModalChiTietNhanXet';
import ModalCapNhatKho from '../Modals/ModalCapNhatKho';
import ModalCapNhatGiaTriGiamGia from '../Modals/ModalCapNhatGiaTriGiam';
import ModalThemVoucher from '../Modals/ModalThemMaGiamGia';
export {
    ModalThemCategory,
    ModalChiTietCategory,
    ModalThemBrand,
    ModalChiTietNhanXet,
    ModalChiTietBrand,
    ModalChiTietProduct_Admin,
    ModalChiTietProduct_ChuShop,
    ModalChiTietDonHang_ChuShop,
    ModalCapNhatKho,
    ModalCapNhatGiaTriGiamGia,
    ModalThemBaiViet,
    ModalChiTietBaiViet,
    ModalChiTietCauHoi,
    ModalThemVoucher
}